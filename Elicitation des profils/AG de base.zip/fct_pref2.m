function pref2=fct_pref2(q,d) %fonction de pr�f�rence en U
    if d<q
        pref2=0;
    else
        pref2=1;
    end

end